/**
 * @swagger
 * components:
 *   schemas:
 *     Book:
 *       type: object
 *       properties:
 *         id:
 *           type: string
 *           description: 도서 ID
 *           example: '0f0f1020101011212123123123123123'
 *         title:
 *           type: string
 *           description: 책 제목
 *           example: '자료구조'
 *         author:
 *           type: string
 *           description: 저자
 *           example: '홍길동'
 *         publisher:
 *           type: string
 *           description: 출판사
 *           example: '한빛미디어'
 *         publishYear:
 *           type: integer
 *           description: 출판 년도
 *           example: 2021
 *         genre:
 *           type: string
 *           description: 장르
 *           example: 'IT'
 *         coverImage:
 *           type: string
 *           description: 책 표지 URL
 *           example: 'https://...'
 *         summary:
 *           type: string
 *           description: 책 줄거리
 *           example: '자료구조에 대한 설명'
 *         tableOfContents:
 *           type: string
 *           description: 책 목차
 *           example: '1장. 자료구조의 개요...'
 *         location:
 *           type: integer
 *           description: 현재 도서 위치 (책장 ID)
 *           example: 1
 */


module.exports = (sequelize, DataTypes) => {
    const Book = sequelize.define('Book', {
        // Model attributes are defined here
        id: {  // 책 ID (PK)
            type: DataTypes.STRING(32),
            primaryKey: true,
        },
        title: {  // 책 제목
            type: DataTypes.STRING(255),
            allowNull: false,
        },
        author: {  // 저자
            type: DataTypes.STRING(100),
            allowNull: false,
        },
        publisher: {  // 출판사
            type: DataTypes.STRING(100),
            allowNull: false,
        },
        publishYear: {  // 출판 년도
            type: DataTypes.INTEGER,
            allowNull: false,
        },
        genre: {  // 장르
            type: DataTypes.STRING(50),
            allowNull: true,
        },
        coverImage: {  // 책 표지 URL
            type: DataTypes.STRING(500),
            allowNull: true,
        },
        summary: {  // 책 줄거리
            type: DataTypes.TEXT,
            allowNull: true,
        },
        tableOfContents: {  // 책 목차
            type: DataTypes.TEXT,
            allowNull: true,
        },
        location: {  // 현재 도서 위치 (책장 ID)
            type: DataTypes.INTEGER,
            allowNull: true,
            references: {
                model: "Shelves",
                key: "id",
            },
        },
    }, {
        timestamps: false,
        tableName: 'books',
        paranoid: true,
        charset: 'utf8',
        collate: 'utf8_general_ci'
    });

    return Book;
};