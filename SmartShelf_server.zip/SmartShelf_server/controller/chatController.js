const { Book } = require("../models");
const shelf = require("../models/shelf");

// LLM 모델과 통신하는 함수 (가정)
//ver1 , LLM http 호출
/*
async function queryLLM(question, books, id) {
    //  LLM 호출 (현재는 더미 응답)
    const llmApiAdress= "http://test.llm.api/query";
    const requestData = {
        question: question,
        books: books.map((book => ({title: book.title, location: book.location}))),
        id: id,
    };

    try{
        const response = await axois.post(llmApiAdress, requestData,{
            headers: {
                "Content-Type": "application/json",
            }
        });
        return response.data.answer
    }
    catch{
        console.error('Error querying LLM: ',error);
        throw new Error("LLM 호출 에러");
    }
}
*/
//ver2 , 동일 서버에서 LLM program 실행
async function queryLLM2(question, bookshelf, id) {
    const llmScriptPath = 'path/to/llm_script.py'; // LLM 모듈 파일 경로

    const requestData = {
        question: question,
        books: bookshelf.map((bookshelf => ({title: bookshelf.title, location: bookshelf.location}))),
    };

    return new Promise((resolve, reject) => {
        const process = execFile('python', [llmScriptPath, JSON.stringify(requestData)], (error, stdout, stderr) => {
            if (error) {
                console.error('Error executing LLM script:', error);
                return reject(new Error('LLM 호출 중 오류가 발생했습니다.'));
            }
            if (stderr) {
                console.error('LLM script stderr:', stderr);
                return reject(new Error('LLM 호출 중 오류가 발생했습니다.'));
            }
            resolve(stdout.trim());
        });
    });
}
/*
    
*/



// LLM에게 질문하기
exports.askLLM = async (req, res) => {
    try {
        const type = 1;
        const question = 2;
        //const { type, question } = req.body;
        if (!question) return res.status(400).json({ error: "질문이 필요합니다." });

        // 현재 책장에 있는 책 목록
        const bookshelfData = await shelf.findAll({ 
            where : bookId != null
        });

        // LLM 호출
        //const response = await queryLLM(question, bookshelfData, userId);
        const response = await queryLLM3(type, question, bookshelfData);
        res.json({ answer: response });
    } catch (err) {
        res.status(500).json({ error: "서버 오류" });
    }
};


//bookshelf => title: bookshelf.title, location: bookshelf.location
function queryLLM3(type, question, bookshelf) {
    const llmScriptPath = 'C:\Users\Choi\Desktop\LLM-main\LLM\main_'; // LLM 모듈 파일 경로

    const requestData = {
        type: type,
        question: question,
        bookshelf: bookshelf.map((bookshelf => ({title: bookshelf.title, location: bookshelf.location}))),
    };

    return new Promise((resolve, reject) => {
        const process = execFile('python', [llmScriptPath, JSON.stringify(requestData)], (error, stdout, stderr) => {
            if (error) {
                console.error('Error executing LLM script:', error);
                return reject(new Error('LLM 호출 중 오류가 발생했습니다.'));
            }
            if (stderr) {
                console.error('LLM script stderr:', stderr);
                return reject(new Error('LLM 호출 중 오류가 발생했습니다.'));
            }
            resolve(stdout.trim());
        });
    });
}
