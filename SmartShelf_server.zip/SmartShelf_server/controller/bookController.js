const { Book, Shelf } = require("../models");
const { Op } = require("sequelize");

// 모든 책 조회 (검색 기능) -> title, genre, description으로 검색 가능
exports.getAllBooks = async (req, res) => {
    try {
        const {body} = req.body;
        const whereClause = {};
        if(body){
            whereClause[Op.or]=[
                { title: {[Op.like]: `%${body}%`}},
                { publisher: {[Op.like]: `%${body}%`}},
                { publishYear: {[Op.like]: `%${body}%`}},
                { genre: {[Op.like]: `%${body}%`}},
                { id: {[Op.like]: `%${body}%`}},
            ];
        }
        const books = await Book.findAll({ 
            where: whereClause,
            attributes: ['title', 'author', 'publisher', 'publishYear', 'genre', 'id', 'location']
        });
        res.json(books);
    } catch (err){
        res.status(500).json({ error: "서버 오류" });
    }
};

// 특정 책 조회
exports.getBookById = async (req, res) => {
    try {
        const { title, category, author, publisher, publishYear } = req.query;
        const whereClause = {};

        if (title) {
            whereClause.title = { [Op.like]: `%${title}%` }; // 부분 검색 가능
        }
        if (category) {
            whereClause.genre = category;
        }
        if (author) {
            whereClause.author = { [Op.like]: `%${author}%` };
        }
        if (publisher) {
            whereClause.publisher = { [Op.like]: `%${publisher}%` };
        }
        if (publishYear) {
            whereClause.publishYear = publishYear;
        }

        const books = await Book.findAll({ 
            where: whereClause
        });
        res.json(books);
    } catch (err) {
        res.status(500).json({ error: "서버 오류" });
    }
};

// 책 상세 정보 조회
exports.getBookDetail = async (req, res) => {
    try {
        const book = await Book.findOne({ where: { title: req.params.title } });
        if (!book) {
            return res.status(404).json({ error: "책을 찾을 수 없음" });
        }
        res.json(book);
    } catch (err) {
        res.status(500).json({ error: "서버 오류" });
    }
};


exports.getBookLocation = async (req,res) => {
    try{
        const book = await Book.find({
            where: {id: req.params.bookdId}
        });
        if(!book){
            return res.status(404).json({error: "책을 찾을 수 없음"});
        }

        const shelf = await Shelf.find({
            where: {bookId: book.id}
        });
        if(!shelf){
            return res.json({error: "현재 없는 책입니다."});
        }
        res.json({
            shelfId: shelf.shelfId,
            row: shelf.row,
            column: shelf.column,
            location: !!shelf.location
        });
    }catch(err){
        res.status(500).json({error: "서버 오류"});
    }
}

// 책 추가 (admin only)
exports.createBook = async (req, res) => {
    try {
        const book = await Book.create(req.body);
        res.status(201).json(book);
    } catch (err) {
        res.status(500).json({ error: "서버 오류" });
    }
};

// 책 정보 수정 (admin only)
exports.updateBook = async (req, res) => {
    try {
        const book = await Book.findByPk(req.params.id);
        if (!book) return res.status(404).json({ error: "책을 찾을 수 없음" });

        await book.update(req.body);
        res.json(book);
    } catch (err) {
        res.status(500).json({ error: "서버 오류" });
    }
};

// 책 삭제 (admin only)
exports.deleteBook = async (req, res) => {
    try {
        const book = await Book.findByPk(req.params.id);
        if (!book) return res.status(404).json({ error: "책을 찾을 수 없음" });

        await book.destroy();
        res.status(204).send();
    } catch (err) {
        res.status(500).json({ error: "서버 오류" });
    }
};
