const express = require("express");
const chatController = require("../controller/chatController");
const mcuController = require("../controller/mcuController");

const router = express.Router();

// LLM과 대화 요청 (사용자 질문 전송)
/**
 * @swagger
 * paths:
 *   /chat:
 *     post:
 *       summary: LLM과 대화 요청
 *       description: 사용자 질문을 LLM에 전송합니다.
 *       requestBody:
 *         description: 사용자 질문 정보
 *         required: true
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 userId:
 *                   type: string
 *                   description: 사용자 ID
 *                   example: 'user123'
 *                 question:
 *                   type: string
 *                   description: 사용자 질문
 *                   example: '책 제목이 무엇인가요?'
 *       responses:
 *         200:
 *           description: LLM 응답
 *           content:
 *             application/json:
 *               schema:
 *                 type: object
 *                 properties:
 *                   answer:
 *                     type: string
 *                     description: LLM의 응답
 *                     example: '책 제목은 자료구조입니다.'
 *         400:
 *           description: 잘못된 요청
 *         500:
 *           description: 서버 오류
 */
router.get("/chat", chatController.askLLM);


router.post("/chat/selectBook", mcuController.selectBook);
module.exports = router;