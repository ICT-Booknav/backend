const express = require("express");
const bookController = require("../controller/bookController");
const mcuController  = require("../controller/mcuController");

const router = express.Router();

// 책 전체 검색 페이지 API
/** 
 * @swagger
 * paths:
 *   /search:
 *     get:
 *       summary: 모든 책 조회
 *       description: 모든 책을 조회합니다. 검색어를 통해 제목, 장르, 설명 중 일치하는 항목이 있는 결과물을 반환합니다.
 *       parameters: 
 *         - name: search
 *           in: query
 *           description: 검색어
 *           required: true
 *           schema:
 *             type: string
 *       responses:
 *         200:
 *           description: 성공
 *           content:
 *             application/json:
 *               schema:
 *                 type: array
 *                 items:
 *                   $ref: '#/components/schemas/Book'
 *         500:
 *           description: 서버 오류
 */
router.get("/search", bookController.getAllBooks);

    
// 책 상세 정보 API
/** 
 * @swagger
 * paths:
 *   /search/{bookid}:
 *     get:
 *       summary: 선택한 책의 모든 정보를 조회합니다.
 *       description: 선택한 책의 모든 정보를 조회합니다.
 *       parameters: 
 *         - name: bookid
 *           in: path
 *           description: 책 코드
 *           required: true
 *           schema:
 *             type: string
 *       responses:
 *         200:
 *           description: 성공
 *           content:
 *             application/json:
 *               schema:
 *                 $ref: '#/components/schemas/Book'
 *         404:
 *           description: 책을 찾을 수 없음
 *         500:
 *           description: 서버 오류
 */
router.get("/search/:bookid", bookController.getBookDetail);

// 책 위치 정보 API (그래픽 표시)
/** 
 * @swagger
 * paths:
 *   /search/{bookid}/location:
 *     get:
 *       summary: 선택한 책의 위치 정보를 반환합니다.
 *       description: 선택한 책의 위치 정보를 반환합니다.
 *       parameters: 
 *         - name: bookid
 *           in: path
 *           description: 책 코드
 *           required: true
 *           schema:
 *             type: string
 *       responses:
 *         200:
 *           description: 성공
 *           content:
 *             application/json:
 *               schema:
 *                 $ref: '#/components/schemas/Shelf'
 *         404:
 *           description: 책을 찾을 수 없음
 *         500:
 *           description: 서버 오류
 */
router.get("/search/:bookid/location", bookController.getBookLocation);

router.get('/search/:bookid/selectBook', bookController.getBookLocation);
//router.post("/search/")
module.exports = router;





// 책 조건별 검색 페이지 API
//router.get('/search/condition', bookController.getBookById);