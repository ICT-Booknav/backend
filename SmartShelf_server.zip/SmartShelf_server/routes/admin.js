const express = require("express");
const bookController = require("../controller/bookController");
//const shelfController = require("../controllers/shelfController");

const router = express.Router();

// 책 전체 검색 페이지 API
/** 
*@swagger
/** 
 * @swagger
 * paths:
 *   /admin/search:
 *     get:
 *       summary: 모든 책 조회
 *       description: 모든 책을 조회합니다. 검색어를 통해 제목, 장르, 설명중 일치하는 항목이 있는 결과물을 반환합니다.
 *       parameters: 
 *         - name: search
 *           in: query
 *           description: 검색어
 *           required: true
 *           schema:
 *             type: string
 *       responses:
 *         200:
 *           description: 성공
 *           content:
 *             application/json:
 *               schema:
 *                 type: array
 *                 items:
 *                   $ref: '#/components/schemas/Book'
 *         500:
 *           description: 서버 오류
 */
router.get("/admin/search", bookController.getAllBooks);


// 책 상세 정보 API
/** 
 * @swagger
 * paths:
 *   /admin/search/{bookid}:
 *     get:
 *       summary: 선택한 책의 모든 정보를 조회합니다.
 *       description: 선택한 책의 모든 정보를 조회합니다.
 *       parameters: 
 *         - name: bookid
 *           in: path
 *           description: 책 코드
 *           required: true
 *           schema:
 *             type: string
 *       responses:
 *         200:
 *           description: 성공
 *           content:
 *             application/json:
 *               schema:
 *                 $ref: '#/components/schemas/Book'
 *         404:
 *           description: 책을 찾을 수 없음
 *         500:
 *           description: 서버 오류
 */
router.get("/admin/serach/:bookid", bookController.getBookDetail);


// 책 관리 API (추가, 수정, 삭제)
/** 
 * @swagger
 * paths:
 *   /admin/books:
 *     post:
 *       summary: 책 추가
 *       description: 새로운 책을 추가합니다.
 *       requestBody:
 *         description: 추가할 책 정보
 *         required: true
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/Book'
 *       responses:
 *         201:
 *           description: 책이 성공적으로 추가됨
 *         500:
 *           description: 서버 오류
 */
router.post("/admin/books", bookController.createBook);

/** 
*  @swagger
*  paths:
*  /admin/books/{id}:
*    put:
*      summary: 책 수정
*      description: 기존 책 정보를 수정합니다.
*      parameters: 
*        - name: id
*          in: path
*          description: 수정할 책의 ID
*          required: true
*          type: string
*        - name: book
*          in: body
*          description: 수정할 책 정보
*          required: true
*          schema:
*            $ref: '#/models/Book'
*      responses:
*        200:
*          description: 책이 성공적으로 수정됨
*        404:
*          description: 책을 찾을 수 없음
*        500:
*          description: 서버 오류
*/
router.put("/admin/books/:id", bookController.updateBook);

/** 
*  @swagger
*  paths:
*  /admin/books/{id}:
*    delete:
*      summary: 책 삭제
*      description: 기존 책을 삭제합니다.
*      parameters: 
*        - name: id
*          in: path
*          description: 삭제할 책의 ID
*          required: true
*          type: string
*      responses:
*        200:
*          description: 책이 성공적으로 삭제됨
*        404:
*          description: 책을 찾을 수 없음
*        500:
*          description: 서버 오류
*/
router.delete("/admin/books/:id", bookController.deleteBook);
module.exports = router;




// 책 조건별 검색 페이지 API
//router.get('/admin/search/condition', bookController.getBookById);
